
import java.util.logging.Level;
import java.util.logging.Logger;


public class Test {
    public static void main(String[] args) {
        Node subInferno1 = new Node("Inferno Left");
        Node subInferno2 = new Node("Inferno Right");
     
        Node subElement1 = new Node("Cold Snap");
        Node subElement2 = new Node("Ice Nova");
        Node subElement3 = new Node("Inferno", subInferno1, subInferno2);
        Node subElement4 = new Node("Ignite");
        
        Node element1 = new Node("Frost", subElement1, subElement2);
        Node element2 = new Node("Fire", subElement3, subElement4);
        Node element3 = new Node("Wizard", element1, element2);
        Tree tree1 = new Tree(element3);
        
        System.out.println(tree1.toString());
                
        try {
            System.out.println(tree1.traceAndPrint("LR"));
            System.out.println(tree1.traceAndPrint("LZ"));
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        try {
            System.out.println(tree1.traceAndPrint("RLLR"));
            System.out.println(tree1.traceAndPrint("RRR"));
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}
