/**
 * This class creates nodes which wrap a generic type and point to two other Node 
children.
 *
 * @author TiKA
 * @date 2022-02-25
 * @modified 2023-03-08
 *
 */
public class Node<T> {
    // attributes: an element, and two children
    private T element;
    private Node<T> left;
    private Node<T> right;
    // simple constructor which wraps an element and sets no children
    public Node(T el) {
        this.element = el;
        this.left = null;
        this.right = null;
    }
    // constructor for creating Nodes with children right away
    public Node(T el, Node<T> l, Node<T> r) {
        this.element = el;
        this.left = l;
        this.right = r;
    }
    // getters & setters
    public T getElement() {
        return element;
    }
    public void setElement(T el) {
        this.element = el;
    }
    public Node<T> getLeft() {
        return left;
    }
    public Node<T> getRight(){
        return right;
    }
    public void setLeft(Node<T> l) {
        this.left = l;
    }
    public void setRight(Node<T> r) {
        this.right = r;
    }
    //Print the node and its children in a horizontal view
    public String printFlat() {
        return printFlat(this);
    }
    //Prints the node and all of its children in a vertical view
    public String printVertical() {
        return printPre(this);
    }
    /**
     * Methods for printing. You do not need to understand these right now.
     * Just using them in your Tree class is fine.
     * You should not adapt these for Task 6.4, you must write it from scratch.
     */
    // generates a string for printing, wrapping each Node in () for moderately 
    //easy viewing
    //NOTE: this is a recursive method. It is not suitable for use in Task 6.4.
    private static String printFlat(Node current) {
        String out = "(";
        // handle an empty node (though these should not be constructable!)
        if (current.element == null) {
            out += "<null> ";
        } else {
            out += "E: <" + current.element.toString() + "> ";
        }
        // stringify the left child and any of its children
        out += "L: ";
        if (current.left == null) {
            out += "<null> ";
        } else {
            out += current.left.printFlat() + " ";
        }
        // stringify the right node and any of its children
        out += "R: ";
        if (current.right == null) {
            out += "<null>";
        } else {
            out +=  current.right.printFlat() + " ";
        }
        out += ")";
        return out;
    }
    //build string for node and prepare to traverse children
    private static String printPre(Node current) {
        //if the node is empty, we can't do anything
        if (current == null) {
            return "";
        }
        //using a string builder to develop an output string
        StringBuilder sb = new StringBuilder();
        //add the current element
        sb.append(current.getElement());
        //pointer for right child
        String pointerRight = "└──";
        //pointer for left child depends whether it has a sibling
        String pointerLeft = (current.getRight() != null) ? "├──" : "└──";
        //now start working on the subtrees--note the parameter 
        //for presence of a right sibling
        printTraverse(sb, "", pointerLeft, current.getLeft(), current.getRight() !=
null);
        printTraverse(sb, "", pointerRight, current.getRight(), false);
        return sb.toString();
    }
    //traversing through the children nodes and build a string representation
    //NOTE: this is a recursive method. It is not suitable for use in Task 6.4.
    private static void printTraverse(StringBuilder sb, String padding, String 
pointer, Node node,
                                      boolean hasRightSibling) {
        //can't do anything with an empty node
        if (node != null) {
            //new line, pad forward, add pointer at this element
            sb.append("\n");
            sb.append(padding);
            sb.append(pointer);
            sb.append(node.getElement());
            //builder for vertical spacing
            StringBuilder paddingBuilder = new StringBuilder(padding);
            if (hasRightSibling) {
                paddingBuilder.append("│  ");
            } else {
                paddingBuilder.append("   ");
            }
            //work out padding and pointers for children nodes
            String paddingForBoth = paddingBuilder.toString();
            String pointerRight = "└──";
            String pointerLeft = (node.getRight() != null) ? "├──" : "└──";
            //handle the left subtree
            printTraverse(sb, paddingForBoth, pointerLeft, node.getLeft(), 
node.getRight() != null);
            //handle the right subtree
            printTraverse(sb, paddingForBoth, pointerRight, node.getRight(), 
false);
        }
    }
}
