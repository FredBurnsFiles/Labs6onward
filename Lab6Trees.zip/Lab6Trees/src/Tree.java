/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2213595
 */

public class Tree<T> {
    private Node root;
    public Tree(Node<T> node){
        this.root = node;      
    }
    
    public Node getRoot(){
        return this.root;
    }
    public void setRoot(Node root) {
        this.root = root;
    }
    @Override
    public String toString() {
        return this.root.printVertical();
    }
    public String traceAndPrint(String path) throws Exception{
        Node current = this.root;
        String state = String.valueOf(this.root.getElement());
        
        for(int i = 0; i < path.length(); i++) {
            
            if(String.valueOf(path.charAt(i)).equals("L")){
                current = current.getLeft();
                
            } else if (String.valueOf(path.charAt(i)).equals("R")){
                current = current.getRight();
                
            } else {
                throw new Exception("Incorrent Character supplied");
            }
            
            if(current == null) {
                throw new Exception("Node not present");
            }
            state = current.getElement() + " - " + state;
        }
        return(state);
    }
}
