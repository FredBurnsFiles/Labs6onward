
public class Country {
    String name;
    HighPoint highPoint;
    Country(String countryName, HighPoint point) {
        name = countryName;
        highPoint = new HighPoint(point.name, point.height);
    }
}
