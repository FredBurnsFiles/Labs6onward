
public class HighPoint {
    String name;
    int height;
    HighPoint(String pointName, int pointHeight) {
        name = pointName;
        height = pointHeight;
    }
}
