
public class Lab9 {
    public static void main(String[] args) {
        Continent southAmerica = new Continent();
        
        Country southAmericanRepublic = new Country(
                "Argentina", new HighPoint("Aconcagua", 6960));
        southAmerica.addCountry(southAmericanRepublic);
        
        Country anotherSouthAmericanRepublic = new Country(
                "Columbia", new HighPoint("Pico Cristóbal Colón",5730));
        southAmerica.addCountry(anotherSouthAmericanRepublic);
        
        System.out.print(southAmerica.allCountries());   
        System.out.print(southAmerica.highestCountry());
    }
}
