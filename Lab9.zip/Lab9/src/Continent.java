import java.util.*;
public class Continent {
    ArrayList<Country> continentList = new ArrayList<>();
    
    void addCountry(Country country) {
        continentList.add(country);
    }
    String allCountries() {
        String countryList = "";
        for(int i = 0; i < continentList.size(); i++) {
            countryList = countryList + continentList.get(i).name +
                    ", Highest Point: ";
            countryList = countryList + continentList.get(i).highPoint.name +
                    ", Height: ";
            countryList = countryList + continentList.get(i).highPoint.height +
                    String.format(".\n");
        }
        return countryList;
    }
    
    String highestCountry() {
       int highestNum = 0;
       int highIndex = 0;
        for(int i = 0; i < continentList.size(); i++) {
            if(continentList.get(i).highPoint.height > highestNum) {
                highestNum = continentList.get(i).highPoint.height;
                highIndex = i;
            }
        }
        return String.format(continentList.get(highIndex).name +
                " has the highest peak " +
                continentList.get(highIndex).highPoint.name +
                " which is at a height of " +
                continentList.get(highIndex).highPoint.height) + "\n";
    }
}
