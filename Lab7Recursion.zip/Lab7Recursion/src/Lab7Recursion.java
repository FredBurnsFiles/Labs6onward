
public class Lab7Recursion {

    public static void main(String[] args) {
      System.out.println(multiply(2,5));
      System.out.println(fib(6));
    }
    
    static int multiply(int n, int m) {
        if(m == 0) {
            return 0;
        } else {
            return (multiply(n, m - 1) + n);
        }
    }
    
    static int fib(int n) {
        if (n == 0) {
            return 0;
        } else if (n == 1){
            return 1;
        } else {
            return fib(n - 1) + fib(n - 2);
        }
    }
    
}
