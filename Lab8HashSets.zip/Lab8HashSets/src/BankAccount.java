
public class BankAccount {
    private final int accNum;
    private final int sortCode;
    public BankAccount(int num, int code){
        this.accNum = num;
        this.sortCode = code;
    }
    
    public boolean equals(Object obj) {
        if (this.hashCode() == obj.hashCode()) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj.getClass().equals(this.getClass()))) {
            return false;
        }
        BankAccount other = ( BankAccount ) obj ;
        if ((other.accNum == this.accNum) && (other.sortCode == this.sortCode)) {
            return true;
        } else {
            return false;
        }

    }
    public int hashCode() {
        return ((this.accNum * 257) + (this.sortCode * 313));
    }

    
    
    @Override
    public String toString() {
        return String.format("Account number: %d \nSort code: %d", accNum, sortCode);
    }
}
