import java.util.HashSet;

public class Test {
    
    public static void main(String[] args) {
        HashSet<BankAccount> bankSet = new HashSet<>();
        bankSet.add(new BankAccount(123000, 321000));
        bankSet.add(new BankAccount(555000, 555000));
        bankSet.add(new BankAccount(123000, 321000));
        
        for (BankAccount i : bankSet) {
            System.out.println(i.toString());
        }
    }
}
